# Project_Kelompok7
Aplikasi Pemesanan Transportasi Online - Kelompok 7 - IF34302 <br>
Judul Aplikasi : RIDER <br>
Scrum Master : Rafi Ihza Maulana (1301140181) <br>

